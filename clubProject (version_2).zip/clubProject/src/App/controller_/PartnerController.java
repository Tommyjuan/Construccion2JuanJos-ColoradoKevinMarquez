/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package App.controller_;

import App.controller.validator.GuestValidator;

/**
 *
 * @author USUARIO
 */
public class PartnerController implements ControllerInterface {
 
    private GuestValidator GuestValidator;
    private static final String MENU = "ingrese la opcion que desea ejecutar: \n 1. para crear mascota. \n 2. para crear dueño de mascota. \n 3. para realizar consulta. \n 4. para anular orden. \n 5. para cerrar sesion.";

    
    
    

    @Override
    public void session() throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
